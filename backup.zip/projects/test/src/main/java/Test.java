import java.net.Socket;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;


public class Test
{
  public static final String EOL = "\r\n";
  
  
  public static void main(String[] args) throws Exception
  {
    Test test = new Test();
    test.test("localhost",9001);
  }


  public void test(String host, int port) throws Exception
  {
    String request = 
    "GET / HTTP/1.1" + EOL +
    "Host: localhost" +  EOL +
    "Connection: keep-alive" +  EOL +
    "sec-ch-ua: \"Google Chrome\";v=\"93\", \" Not;A Brand\";v=\"99\", \"Chromium\";v=\"93\"" +  EOL +
    "sec-ch-ua-mobile: ?0" +  EOL +
    "sec-ch-ua-platform: \"macOS\"" +  EOL +
    "Upgrade-Insecure-Requests: 1" +  EOL +
    "User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36" +  EOL +
    "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9" +  EOL +
    "Sec-Fetch-Site: none" +  EOL +
    "Sec-Fetch-Mode: navigate" +  EOL +
    "Sec-Fetch-User: ?1" +  EOL +
    "Sec-Fetch-Dest: document" +  EOL +
    "Accept-Encoding: gzip, deflate, br" +  EOL +
    "Accept-Language: en-US,en;q=0.9,da;q=0.8" + EOL + EOL;
    
    //port = 80;
    //host = "rpi";
    
    Socket socket = new Socket(host,port);
    invoke(socket,request);
    //Thread.sleep(1000);
    //invoke(socket,request);
    socket.close();
  }
  
  
  public byte[] invoke(Socket socket, String request) throws Exception
  {
    return(invoke(socket.getInputStream(),socket.getOutputStream(),request));
  }
  
  
  public byte[] invoke(InputStream in, OutputStream out, String request) throws Exception
  {
    out.write(request.getBytes());
    SocketReader reader = new SocketReader(in);

    int bytes = 0;
    ArrayList<String> headers = reader.getHeader();
    
    for (String header : headers)
    {
      System.out.println(header);
      if (header.startsWith("Content-Length"))
      {
        int pos = header.indexOf(':',14);
        String cl = header.substring(pos+1);
        bytes = Integer.parseInt(cl.trim());
      }
    }
    
    byte[] body = reader.getContent(bytes);
    System.out.println(new String(body));

    return(null);
  }
}
