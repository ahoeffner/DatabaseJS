package handlers;

import config.Config;
import server.HTTPRequest;
import server.HTTPResponse;


public class RestHandler implements Handler
{
  @Override
  public void handle(Config config, HTTPRequest request, HTTPResponse response)
  {
    // TODO Implement this method
  }
}
