package handlers;


public class RestHandler implements Handler
{
  @Override
  public void handle()
  {
    // TODO Implement this method
  }
}
