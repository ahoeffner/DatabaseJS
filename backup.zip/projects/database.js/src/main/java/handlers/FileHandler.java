package handlers;


public class FileHandler implements Handler
{
  @Override
  public void handle()
  {
    // TODO Implement this method
  }
}
