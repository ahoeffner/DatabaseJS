package handlers;

public interface Handler
{
  void handle();
}
