package database.js.pools;

public interface PoolResponse
{
  void respond(byte[] data) throws Exception;
}
