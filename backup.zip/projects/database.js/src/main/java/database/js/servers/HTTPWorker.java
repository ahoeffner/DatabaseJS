package database.js.servers;

import java.nio.channels.SocketChannel;


public class HTTPWorker implements Runnable
{
  public HTTPWorker(SocketChannel channel, HTTPRequest request, boolean embedded, boolean admin)
  {
  }


  @Override
  public void run()
  {
  }
}
